class Validator{

    data : number | string | boolean | undefined | null = 2;   

}